var cel=document.getElementById("celcius");
var fah=document.getElementById("fahrenheit");
let clearbtn = document.querySelector('.clear_btn');
let bodytag = document.querySelector('.body_tag');
cel.value=' ';
fah.value=' ';
let c_val = '';
let f_val = ' ';
cel.addEventListener('input',function(){
    let celval=this.value;
    // console.log(c);
    
    let f=((celval * 9/5) + 32);
    
    if(!Number.isInteger(f)){
        f=f.toFixed(2);
        f_val = f;
    }
    console.log(f);
    // backchange();
    fahrenheit.value=f;
    if( (f>=21 && f<=68)){
        
        bodytag.style.backgroundColor='powderblue';
    }
    else if(f>68){
        bodytag.style.backgroundColor="rgba(255,0,0,0.5)";
    }
   // console.log("celcius changed");
});
fah.addEventListener('input',function(){
    //console.log("fahrenheit changed");
    let f=this.value;

    let c=(f-32)*(5/9);
    if(!Number.isInteger(c)){
        c=c.toFixed(2);
        c_val=c;
    }
  
    if( (c<=21 && c<=68)){
        if((c>=21 && c<=68)){
        bodytag.style.backgroundColor='powderblue';
    }
    }
    else if(c>68 && c<100) {
        bodytag.style.backgroundColor="rgba(255,0,0,0.5)";
    }
    celcius.value=c;
})

clearbtn.addEventListener('click',()=>{
    cel.value=' ';
    fah.value=' ';
})







